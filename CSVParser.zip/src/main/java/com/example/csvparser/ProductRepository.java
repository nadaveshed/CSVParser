package com.example.csvparser;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Player, Integer> {

}
